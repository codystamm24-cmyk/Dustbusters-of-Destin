Dustbusters of Destin — Full Flutter Project (FINAL)
===================================================

App Name: Dustbusters of Destin
Primary phone: 850-714-4149
Secondary phone: 850-803-4091

WHAT'S INCLUDED
- Full Flutter project skeleton (lib/, android/, ios/)
- Firebase placeholders (replace with your firebase_options.dart)
- Stripe backend sample (backend_node/)
- GitHub Actions workflow to build Android APK
- README_RELEASE_INSTRUCTIONS.txt with local & CI build steps

IMPORTANT: Security & keys
- This package contains placeholders for Firebase and Stripe.
- Do NOT commit your secret keys to public repos.
- Replace the following placeholders with your actual credentials:
  - In backend_node/index.js set STRIPE_SECRET via environment variable
  - In lib/services/firebase_options_stub.dart replace with generated firebase_options.dart
  - In lib/services/stripe_service or HomeScreen set your Stripe publishable key and backendUrl

QUICK START (macOS)
1. Install Flutter SDK: https://docs.flutter.dev/get-started/install/macos
2. Unzip this archive and open the folder in Terminal.
3. Run:
   flutter pub get
4. To run on device:
   flutter run
5. To build APK:
   flutter build apk --release

STRIPE BACKEND (local testing)
1. cd backend_node
2. npm install
3. Create a .env or set STRIPE_SECRET environment variable:
   export STRIPE_SECRET=sk_test_xxx
4. npm start
5. Use the backend URL (http://localhost:4242) in the app StripeService backendUrl.

FIREBASE SETUP
- Run `flutterfire configure` in the project root to generate firebase_options.dart.
- Place google-services.json (Android) and GoogleService-Info.plist (iOS) in the respective platform folders.

If you want, I can:
- Generate firebase_options.dart for you if you provide Firebase project id and app bundle ids.
- Deploy the Node backend to Heroku/Vercel and show exact URLs.
- Add APK signing to GitHub Actions and guide you through Play Store release.