const express = require('express');
const app = express();
const stripe = require('stripe')(process.env.STRIPE_SECRET || 'sk_test_PLACEHOLDER');
app.use(express.json());
app.post('/create-payment-intent', async (req, res) => {
  try {
    const { amount } = req.body;
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount,
      currency: 'usd',
      automatic_payment_methods: { enabled: true },
    });
    res.json({ client_secret: paymentIntent.client_secret });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});
const PORT = process.env.PORT || 4242;
app.listen(PORT, () => console.log('Stripe backend running on port', PORT));