/// Placeholder firebase_options.dart
/// Generate real options with `flutterfire configure` and replace this file.
class DefaultFirebaseOptions {
  static get currentPlatform => null;
}