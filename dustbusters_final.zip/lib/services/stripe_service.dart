import 'dart:convert';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;

class StripeService {
  final String backendUrl;
  StripeService({required this.backendUrl});
  void init(String publishableKey) {
    Stripe.publishableKey = publishableKey;
    Stripe.merchantIdentifier = 'merchant.dustbusters';
  }
  Future<Map<String,dynamic>> createPaymentIntentOnBackend(int amountCents, String currency) async {
    final resp = await http.post(Uri.parse('$' + '{backendUrl}' + '/create-payment-intent'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'amount': amountCents, 'currency': currency}),
    );
    return jsonDecode(resp.body) as Map<String,dynamic>;
  }
  Future<void> payWithCard(int amountCents) async {
    final intent = await createPaymentIntentOnBackend(amountCents, 'usd');
    final clientSecret = intent['client_secret'] as String;
    await Stripe.instance.initPaymentSheet(paymentSheetParameters: SetupPaymentSheetParameters(paymentIntentClientSecret: clientSecret, merchantDisplayName: 'Dustbusters of Destin'));
    await Stripe.instance.presentPaymentSheet();
  }
}