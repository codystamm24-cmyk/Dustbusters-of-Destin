import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;
  CollectionReference bookingsRef() => _db.collection('bookings');
  Future<DocumentReference> createBooking(Map<String, dynamic> data) {
    return bookingsRef().add(data);
  }
  Stream<QuerySnapshot> bookingsStream() {
    return bookingsRef().orderBy('createdAt', descending: true).snapshots();
  }
}