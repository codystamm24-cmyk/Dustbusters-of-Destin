import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'services/firebase_options_stub.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Replace DefaultFirebaseOptions.currentPlatform with the generated firebase_options.dart
  runApp(DustbustersApp());
}

class DustbustersApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Dustbusters of Destin',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: HomeScreen(),
    );
  }
}