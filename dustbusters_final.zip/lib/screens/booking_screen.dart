import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class BookingScreen extends StatefulWidget {
  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _address = TextEditingController();
  final _sqft = TextEditingController();
  String type = 'Normal Clean';
  DateTime when = DateTime.now().add(Duration(days:1));
  bool oven=false, fridge=false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Book a Clean')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Form(
          key: _formKey,
          child: ListView(children:[
            DropdownButtonFormField<String>(value: type, items: ['Normal Clean','Deep Clean','Move-in/Move-out'].map((s)=>DropdownMenuItem(value:s,child:Text(s))).toList(), onChanged: (v){ if(v!=null) setState(()=>type=v);}, decoration: InputDecoration(labelText: 'Service Type')),
            TextFormField(controller: _name, decoration: InputDecoration(labelText: 'Name'), validator: (v)=> v==null||v.isEmpty? 'Required':null),
            TextFormField(controller: _address, decoration: InputDecoration(labelText: 'Address')),
            TextFormField(controller: _sqft, decoration: InputDecoration(labelText: 'Square Footage'), keyboardType: TextInputType.number),
            ListTile(title: Text('Preferred Date: ' + DateFormat.yMMMd().format(when)), trailing: Icon(Icons.calendar_month), onTap: pickDate),
            CheckboxListTile(value: oven, onChanged: (v)=> setState(()=>oven=v??false), title: Text('Inside oven')),
            CheckboxListTile(value: fridge, onChanged: (v)=> setState(()=>fridge=v??false), title: Text('Inside fridge')),
            SizedBox(height:12),
            ElevatedButton(onPressed: submit, child: Text('Submit')),
          ]),
        ),
      ),
    );
  }

  void pickDate() async {
    final d = await showDatePicker(context: context, initialDate: when, firstDate: DateTime.now(), lastDate: DateTime.now().add(Duration(days:365)));
    if(d!=null) setState(()=>when=d);
  }

  void submit() async {
    if(!(_formKey.currentState?.validate() ?? false)) return;
    final data = {
      'type': type,
      'name': _name.text,
      'address': _address.text,
      'sqft': int.tryParse(_sqft.text) ?? 0,
      'date': when.toIso8601String(),
      'addOns': {'oven': oven, 'fridge': fridge},
      'createdAt': DateTime.now().toIso8601String(),
    };
    // For demo this app doesn't push to backend yet.
    showDialog(context: context, builder: (_) => AlertDialog(title: Text('Requested'), content: Text('Booking requested (demo).'), actions: [TextButton(child: Text('OK'), onPressed: ()=> Navigator.of(context)..pop()..pop())]));
  }
}