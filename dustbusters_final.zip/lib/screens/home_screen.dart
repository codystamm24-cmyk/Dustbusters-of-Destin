import 'package:flutter/material.dart';
import 'booking_screen.dart';
import '../services/firestore_service.dart';
import '../services/stripe_service.dart';
import 'package:url_launcher/url_launcher.dart';

class HomeScreen extends StatelessWidget {
  final _fs = FirestoreService();
  final _stripe = StripeService(backendUrl: 'https://your-backend.example.com'); // replace with your backend URL
  final String primaryPhone = '850-714-4149';
  final String secondaryPhone = '850-803-4091';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Dustbusters of Destin')),
      body: ListView(padding: EdgeInsets.all(16), children: [
        Text('Welcome to Dustbusters of Destin', style: Theme.of(context).textTheme.headline6),
        SizedBox(height:8),
        ElevatedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BookingScreen())), icon: Icon(Icons.calendar_today), label: Text('Book a Clean')),
        SizedBox(height:12),
        Card(child: ListTile(leading: Icon(Icons.phone), title: Text('Call Now'), subtitle: Text(primaryPhone), onTap: () => _launchPhone(primaryPhone))),
        SizedBox(height:12),
        Card(child: ListTile(leading: Icon(Icons.phone_android), title: Text('Secondary Contact'), subtitle: Text(secondaryPhone), onTap: () => _launchPhone(secondaryPhone))),
        SizedBox(height:12),
        ElevatedButton(onPressed: () => _paySample(context), child: Text('Pay \$50 (Demo)')),
      ]),
    );
  }

  void _launchPhone(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  void _paySample(BuildContext ctx) async {
    try {
      await _stripe.payWithCard(5000);
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Payment completed')));
    } catch(e) {
      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(content: Text('Payment failed: \$e')));
    }
  }
}